<? if($_SESSION['SESS_MSG']!=''){?><div class="errormsg" style="color:#FF0000" ><span class="errormsg" style="color:#FF0000">
<?=$_SESSION['SESS_MSG']?>
</span></div>
<? $_SESSION['SESS_MSG']='';}?>
 
