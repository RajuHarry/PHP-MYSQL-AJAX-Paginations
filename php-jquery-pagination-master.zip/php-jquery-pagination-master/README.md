php-jquery-pagination
=====================

Simple php and ajax pagination.
