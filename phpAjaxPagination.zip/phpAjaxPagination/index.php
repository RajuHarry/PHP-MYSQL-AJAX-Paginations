<?php
include_once('inc/dbConnect.inc.php');
include_once('inc/pagination.inc.php');
$query="select id from pagination order by id desc";
$res=mysql_query($query);
$count=mysql_num_rows($res);
if($count > 0){
   $paginationCount=getPagination($count);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP Ajax Pagination Tutorial | 91 Web Lessons</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
<script type="text/javascript">
function changePagination(pageId,liId){
      $(".flash").show();
      $(".flash").fadeIn(400).html('Loading <img src="image/ajax-loading.gif" />');
      var dataString = 'pageId='+ pageId;
      $.ajax({
      type: "POST",
      url: "pageData.php",
      data: dataString,
      cache: false,
      success: function(result){
               $(".flash").hide();
               $(".link a").css('background-color','#fff') ;
               $("#"+liId+" a").css('background-color','#99A607') ;
               $("#pageData").html(result);
      }
      });
}
</script>
</head>
<body onload="changePagination('0','first')">
<div id="container">
    <!--top section start-->
    <div id='top'>
         <a href="http://www.91weblessons.com" title="91 Web Lessons" target="blank">
             <img src="image/logo.png" alt="91 Web Lessons" title="91 Web Lessons" border="0"/>
         </a>
    </div>

    <div id='tutorialHead'>
         <div class="tutorialTitle"><h1>PHP Ajax Pagination Tutorial</h1></div>
         <div class="tutorialLink"><a href="http://www.91weblessons.com/php-ajax-pagination-tutorial" title="PHP Ajax Pagination Tutorial"><h1>Tutorial Link</h1></a></div>

    </div>

    <div id="wrapper">
         <div id="pageData"></div>
          <?php
            if($count > 0){
          ?>
          <ul>
               <li class='first link' id="first"><a href="javascript:void(0)" onclick="changePagination('0','first')">First</a></li>
               <?php
               for($i=0;$i<$paginationCount;$i++){
                  ?><li id="<?php echo $i;?>_no" class='link'><a href="javascript:void(0)" onclick="changePagination('<?php echo $i;?>','<?php echo $i;?>_no')"><?php echo $i+1;?></a></li><?php
               }
               ?>
               <li class='last link'  id="last"><a href="javascript:void(0)" onclick="changePagination('<?php echo $paginationCount-1;?>','last')">Last</a></li>
               <li class="flash"></li>
          </ul>
          <?php } ?>
    </div>


    <!--fotter section start-->
    <div id="fotter">
         <p>Copyright &copy; 2012
              <a href="http://www.91weblessons.com" title="91 Web Lessons" target="blank">91 Web Lessons</a>.
              All rights reserved.
         </p>
    </div>
</div>
</body>
</html>
