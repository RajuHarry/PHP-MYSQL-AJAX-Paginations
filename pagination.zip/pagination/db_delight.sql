-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 27, 2013 at 07:11 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db`
--

-- --------------------------------------------------------


--
-- Table structure for table `tbl_enquiry`
--

CREATE TABLE IF NOT EXISTS `tbl_enquiry` (
  `id` mediumint(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `message` longtext NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_enquiry`
--

INSERT INTO `tbl_enquiry` (`id`, `name`, `mobile`, `email`, `message`, `status`) VALUES
(1, 'testing', '919821197163', 'tester@ccomsys.net', 'testing message ', 0),
(2, 'kalepsh', '9870846941', 'kalpesh@ccomswys.net', 'We develop sales training for both entry and senior-level professionals.\r\n\r\nThe entry level programs cover basic skills including:\r\n\r\nTelephone etiquette\r\nProduct presentation\r\nHandling objections\r\nCross-selling\r\nProblem solving\r\nThe advanced program focuses on:\r\nForging deals\r\nDealing with competition\r\nCustomizing product/service offerings\r\nEmpowering your Sales Force\r\n\r\nEach phase of a sales process-starting from cold calling to closing the sale-involves a specific set of skills. The sales training programs created by TIS address the specialized skills required at each stage. ', 0),
(3, 'kalepsh', '9870846941', 'kalpesh@ccomswys.net', 'We develop sales training for both entry and senior-level professionals.\r\n\r\nThe entry level programs cover basic skills including:\r\n\r\nTelephone etiquette\r\nProduct presentation\r\nHandling objections\r\nCross-selling\r\nProblem solving\r\nThe advanced program focuses on:\r\nForging deals\r\nDealing with competition\r\nCustomizing product/service offerings\r\nEmpowering your Sales Force\r\n\r\nEach phase of a sales process-starting from cold calling to closing the sale-involves a specific set of skills. The sales training programs created by TIS address the specialized skills required at each stage. ', 0),
(4, 'aasd', '914323', 'fdfsf@gmail.co', 'sdfsdfsd', 0),
(5, 'vishal', '8976131836', 'vishal@ccomsys.net', 'ggfgfdgdfgfkglfg\r\njfngkdfkgfdkgf\r\nfgdfgdfgflgfg;fgdfgdfgfgg lkklklgfkgkdfgfgfkgdfg\r\nkfjgdfjgldfgjdflgjflgjflglfgl', 0),
(6, 'vishal', '8976131836', 'vishal@ccomsys.net', 'ggfgfdgdfgfkglfg\r\njfngkdfkgfdkgf\r\nfgdfgdfgflgfg;fgdfgdfgfgg lkklklgfkgkdfgfgfkgdfg\r\nkfjgdfjgldfgjdflgjflgjflglfgl', 0);

-- --------------------------------------------------------
