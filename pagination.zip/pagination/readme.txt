

1) Open localhost/phpmyadmin on web browser

2) create batabase 'db' 

3) import .sql file on 'db database'

4) after completed inporing then open your browser and 

paste the link localhost/pagination/page.php (for normal pagination this fetch full table including table header)

and

		localhost/pagination/enquiries.php (this is customizable)