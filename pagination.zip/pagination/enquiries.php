
<!DOCTYPE html>
<head>
    <title>:: Enquiries</title>
   
    <link rel="stylesheet" type="text/css" href="css/demo.css" />
	
	
<style>
#page-wrap {
    margin: 50px;
}
p {
    margin: 20px 0; 
}

    /* 
    Generic Styling, for Desktops/Laptops 
    */
    table { 
        width: 100%; 
        border-collapse: collapse; 
    }
    /* Zebra striping */
    tr:nth-of-type(odd) { 
        background: #E7E7E7; 
    }
    th {         
        border: 1px solid #ccc; 
        text-align: left; 
         font-weight: bold;
    text-indent: 13px;
    width: 110px !important;
    }
    td { 
        padding: 6px; 
        border: 1px solid #ccc; 
        text-align: left; 
    }
	
	
	
	
	


/*LMS DATA TABLE*/
.ewTable {
	width: inherit; /* table width */	
	color: inherit; /* text color */
	font-family: Tahoma;
	font-size: 12px;
	border: 0px outset; /* border */
	border-collapse: collapse;
	padding-left: 10px; /* cell padding */
	margin-left: 35px; /* cell padding */
	margin-bottom: 25px; /* cell padding */
}
.ewTable th,
.ewTable td {
	padding: 4px; /* cell padding */
	border: 1px solid; /* cell spacing */
	border-color: #CCCCCC;  /* table background color */
}
.ewTableHeader {
	background-color: #5E9ADD; /* header color */
	color: #00234B; /* header font color */	
	font-size: 12px;
	vertical-align: top;	
}
.ewTableHeader a:link {	
	color: #FFFFFF; /* header font color */	
}
.ewTableHeader a:visited {	
	color: #FFFFFF; /* header font color */	
}
/* main table row color */
.ewTableRow {
	background-color: #F0F0F0;  /* alt row color 1 */
	color: #000000;
    font-family: Tahoma;
    font-size: 11px;
    padding-bottom: 5px;
    padding-left: 5px;
    padding-top: 5px;
}

/* main table alternate row color */
.ewTableAltRow {
	background-color: #E9E9E9; /* alt row color 2 */	
	color: #000000;
    font-family: Tahoma;
    font-size: 11px;
    padding-bottom: 5px;
    padding-left: 5px;
    padding-top: 5px;
}

table tr.ewTableRow:hover,
table tr.ewTableAltRow:hover
{
	/* background-color: #0066FF; */
	 background-color: #fff; 
}




/* Pagination     */
.paginate {
font-family:Arial, Helvetica, sans-serif;
	padding: 3px;
	margin-left: 30px;
	margin-top: 10px;
	padding-top: 10px;
}

.paginate a {
	padding:2px 5px 2px 5px;
	margin:2px;
	border:1px solid #999;
	text-decoration:none;
	color: #666;
}
.paginate a:hover, .paginate a:active {
	border: 1px solid #999;
	color: #000;
}
.paginate span.current {
    margin: 2px;
	padding: 2px 5px 2px 5px;
		border: 1px solid #999;
		
		font-weight: bold;
		background-color: #999;
		color: #FFF;
	}
	.paginate span.disabled {
		padding:2px 5px 2px 5px;
		margin:2px;
		border:1px solid #eee;
		color:#DDD;
	}
	
	



#box-table-a {
    border-collapse: collapse;
    font-family: "Lucida Sans Unicode","Lucida Grande",Sans-Serif;
    font-size: 12px;
    text-align: left;
}	
	
	#box-table-a td {
    background: none repeat scroll 0 0 #E8EDFF;
    border-bottom: 1px solid #FFFFFF;
    border-top: 1px solid transparent;
    color: #666699;
    padding: 8px;
}
</style>
          
</head>
<body>

<?php

 ?>  
<div id="midfooter" >
<?php
	/*
		Place code to connect to your DB here.
	*/
	include('config.php');	// include your code to connect to DB.

	
	$targetpage = "enquiries.php";
	$total_leads = "SELECT * from tbl_enquiry";
	$total_rows = mysql_query($total_leads);
	
	$limit = 2;
	
	$query = "SELECT COUNT(*) as num FROM tbl_enquiry";
	
	$result = mysql_query($query) or die(mysql_error());
    $total_pages = mysql_fetch_array($result);
    $total_pages = $total_pages['num'];
	
	$stages = 3;
        //$page = mysql_escape_string(isset($_GET['page']));
        $page = isset($_GET['page']) ? $_GET['page'] : '';
        if ($page) {
            $start = ($page - 1) * $limit;
        } else {
            $start = 0;
        }
	
	 // Get page data
        $query1 = $total_leads . " LIMIT $start,$limit ";
        $result1 = mysql_query($query1);
        $numfields = mysql_num_fields($result1);
        //$_SESSION["export_query"] = $total_leads;
		
		 // Initial page num setup
        if ($page == 0) {
            $page = 1;
        }
        $prev = $page - 1;
        $next = $page + 1;
        $lastpage = ceil($total_pages / $limit);
        $LastPagem1 = $lastpage - 1;

		$paginate = '';
        if ($lastpage > 1) {
            $paginate .= "<div class='paginate'>";
            // Previous
            if ($page > 1) {
                $paginate.= "<a href='$targetpage?page=$prev'>previous</a>";
            } else {
                $paginate.= "<span class='disabled'>previous</span>";
            }

            // Pages	
            if ($lastpage < 7 + ($stages * 2)) { // Not enough pages to breaking it up
                for ($counter = 1; $counter <= $lastpage; $counter++) {
                    if ($counter == $page) {
                        $paginate.= "<span class='current'>$counter</span>";
                    } else {
                        $paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";
                    }
                }
            } elseif ($lastpage > 5 + ($stages * 2)) { // Enough pages to hide a few?
                // Beginning only hide later pages
                if ($page < 1 + ($stages * 2)) {
                    for ($counter = 1; $counter < 4 + ($stages * 2); $counter++) {
                        if ($counter == $page) {
                            $paginate.= "<span class='current'>$counter</span>";
                        } else {
                            $paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";
                        }
                    }
                    $paginate.= "...";
                    $paginate.= "<a href='$targetpage?page=$LastPagem1&'>$LastPagem1</a>";
                    $paginate.= "<a href='$targetpage?page=$lastpage'>$lastpage</a>";
                }
                // Middle hide some front and some back
                elseif ($lastpage - ($stages * 2) > $page && $page > ($stages * 2)) {
                    $paginate.= "<a href='$targetpage?page=1'>1</a>";
                    $paginate.= "<a href='$targetpage?page=2'>2</a>";
                    $paginate.= "...";
                    for ($counter = $page - $stages; $counter <= $page + $stages; $counter++) {
                        if ($counter == $page) {
                            $paginate.= "<span class='current'>$counter</span>";
                        } else {
                            $paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";
                        }
                    }
                    $paginate.= "...";
                    $paginate.= "<a href='$targetpage?page=$LastPagem1'>$LastPagem1</a>";
                    $paginate.= "<a href='$targetpage?page=$lastpage'>$lastpage</a>";
                }
                // End only hide early pages
                else {
                    $paginate.= "<a href='$targetpage?page=1'>1</a>";
                    $paginate.= "<a href='$targetpage?page=2'>2</a>";
                    $paginate.= "...";
                    for ($counter = $lastpage - (2 + ($stages * 2)); $counter <= $lastpage; $counter++) {
                        if ($counter == $page) {
                            $paginate.= "<span class='current'>$counter</span>";
                        } else {
                            $paginate.= "<a href='$targetpage?page=$counter'>$counter</a>";
                        }
                    }
                }
            }

            // Next
            if ($page < $counter - 1) {
                $paginate.= "<a href='$targetpage?page=$next'>next</a>";
            } else {
                $paginate.= "<span class='disabled'>next</span>";
            }

            $paginate.= "</div>";
        }
        /**/
		?>
		<table style="margin: 10px;width: 98%;">     
    <tr>
        <th id="purchase">Name</th>
        <th id="purchase">Mobile </th>
        <th id="purchase" >Email</th>
		<th id="purchase" >Enquiry</th>
		
        </tr>
 <?php
 while($data = mysql_fetch_assoc($result1))
 {
?>  
        <tr>
            <td id="till"><?php echo $data['name']; ?></td>
            <td id="till"><?php echo $data['mobile']; ?></td>
            <td id="till"><?php echo $data['email']; ?></td>
			 <td id="till"><?php echo $data['message']; ?></td>

    </tr> 
 <?php
}
?> 
</table>
		
		
		
	<?php	
		
		
		
		
		
        // echo "<table class='ewTable' id='our' align='left' valign='middle'>\n";

        // echo "<tr class='ewTableHeader' >";

        // for ($i = 0; $i < $numfields; $i++) 
		// { // Header
            // echo '<th>' . strtoupper(mysql_field_name($result1, $i)) . '</th>';
        // }
        // //echo '<th colspan="4">Action</th>';
        // echo "</tr>";

        // $altrowcount = 0;
        // $i = 0;
        // $j = $start + 1;
        // while ($row = mysql_fetch_row($result1)) 
		// { // Data

            // $altrowcount++;
    
    
            // if ($altrowcount % 2) {
                // $classname = "ewTableAltRow";
            // } else {
                // $classname = "ewTableRow";
            // }
           
            

            // echo "<tr class='$classname' id='tr_$i'>";

            // for ($i = 0; $i < $numfields; $i++) 
			// { // Header
                // if($i == 0){
                    // echo '<td>' . $j . '</td>';
                // }else if ($i == 2) {
                   // echo '<td>' . $row[$i] . '</td>';
                // } else if ($i == 6) {
                   // echo "<td class='show' >" .$row[$i] . "</td>";
                // } else {
                    // echo '<td>' . $row[$i] . '&nbsp;</td>';
                // }
            // }

            
            // echo "</tr>\n";
            // $i++;
            // $j++;
        // } //end of while loop

        // echo "</table>\n\n\n";
		
		
		
		
        //echo $total_pages.' Results';
        echo "<br/><br/>" . $paginate;
    //end of Submit action
    ?>
<p>&nbsp;</p><p>&nbsp;</p>
</div>

</body>
</html>
