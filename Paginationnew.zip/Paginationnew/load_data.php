<?php
if($_POST['page'])
{
$page = $_POST['page'];
$cur_page = $page;
$page -= 1;
$per_page = 2;
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
$start = $page * $per_page;
include"db.php";

$query_pag_data = "SELECT * from student1 LIMIT $start, $per_page";
$result_pag_data = mysql_query($query_pag_data) or die('MySql Error' . mysql_error());



/* --------------------------------------------- */
$query_pag_num = "SELECT COUNT(*) AS count FROM student1";
$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];
$no_of_paginations = ceil($count / $per_page);

/* ---------------Calculating the starting and endign values for the loop----------------------------------- */
if ($cur_page >= 7) {
    $start_loop = $cur_page - 3;
    if ($no_of_paginations > $cur_page + 3)
        $end_loop = $cur_page + 3;
    else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
        $start_loop = $no_of_paginations - 6;
        $end_loop = $no_of_paginations;
    } else {
        $end_loop = $no_of_paginations;
    }
} else {
    $start_loop = 1;
    if ($no_of_paginations > 7)
        $end_loop = 7;
    else
        $end_loop = $no_of_paginations;
}
/* ----------------------------------------------------------------------------------------------------------- */


}


////////////////////////////////////////////////////////////////

?>
<br />
<table id='tbl' align="center" cellpadding="10" border="0" >
                            <thead>        
                                <tr> <th class="checkbox" >Check</th>
                                    <th class="checkbox">ID</th>
                                    <th>First Name</th>
                                    <th>Middle Name</th>
                                    <th>Surname</th>
                                    <th>DOB</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Year</th>
                                    <th class="checkbox" >Other Details</th>
                                    <th class="checkbox" >Edit</th>
                                    <th class="checkbox" >Delete</th>

                                </tr> 
                            </thead>
                            <tbody> 
                            
                            
                            
<?php
$i = 1;
$msg = "";
while ($row = mysql_fetch_array($result_pag_data)) {
//$htmlmsg=htmlentities($row['message']);
   // $msg .= "<li><b>" . $row['id'] . "</b> " . $htmlmsg . "</li>";
//}
//$msg = "<div class='data'><ul>" . $msg . "</ul></div>"; // Content for Data
?>

<tr>

                                        <td ><input type="checkbox" id='del[]' value='<?php echo $row['id']; ?>' name='del[]'></td>
                                        <td>
                                            <?php echo $i; ?>
                                        </td>
                                        <td><?php echo $row['fname']; ?></td>
                                        <td><?php echo $row['mname']; ?></td>
                                        <td><?php echo $row['lname']; ?></td>
                                        <td><?php echo $row['dob']; ?></td>
                                        <td><?php echo $row['email']; ?></td>
                                        <td><?php echo $row['phone']; ?></td> 
                                        <td><?php echo $row['class']; ?></td>
                                        <td><a href="otherstudent.php?id=<?php echo $row['id']; ?> "><img src="images/vcard.png" title="Other Details" alt="Other Details" class="icondetail"/></td>
                                        <td><a href="Editstudent.php?id=<?php echo $row['id']; ?> "><img src="images/Edit.png" title="Edit" alt="Edit"  class="iconimg"/></a></td>
                                        <td><a onclick="return del();" href="studentadd.php?id=<?php echo $row['id']; ?>"><img src="images/del7.png" title="Delete" alt="Delete" class="iconimg"/></a></td>

                                    </tr>
                                    <?php
                                    $i++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <br />
<?php
                        $msg .= "<div class='pagination'><ul id='paginateul'>";

// FOR ENABLING THE FIRST BUTTON
if ($first_btn && $cur_page > 1) {
    $msg .= "<li p='1' class='active'>First</li>";
} else if ($first_btn) {
    $msg .= "<li p='1' class='inactive'>First</li>";
}

// FOR ENABLING THE PREVIOUS BUTTON
if ($previous_btn && $cur_page > 1) {
    $pre = $cur_page - 1;
    $msg .= "<li p='$pre' class='active'>Previous</li>";
} else if ($previous_btn) {
    $msg .= "<li class='inactive'>Previous</li>";
}
for ($i = $start_loop; $i <= $end_loop; $i++) {

    if ($cur_page == $i)
        $msg .= "<li p='$i' style='color:#fff;background-color:#5d6677;' class='active'>{$i}</li>";
    else
        $msg .= "<li p='$i' class='active'>{$i}</li>";
}

// TO ENABLE THE NEXT BUTTON
if ($next_btn && $cur_page < $no_of_paginations) {
    $nex = $cur_page + 1;
    $msg .= "<li p='$nex' class='active'>Next</li>";
} else if ($next_btn) {
    $msg .= "<li class='inactive'>Next</li>";
}

// TO ENABLE THE END BUTTON
if ($last_btn && $cur_page < $no_of_paginations) {
    $msg .= "<li p='$no_of_paginations' class='active'>Last</li>";
} else if ($last_btn) {
    $msg .= "<li p='$no_of_paginations' class='inactive'>Last</li>";
}
// Go button if needed
$goto = "<div style='float:left;margin: 16px 0px;'><div style='float:left'><input type='text' class='goto' size='1' style='margin-top:-1px;margin-left:60px;'/></div><div style='float:left'><input type='button' id='go_btn' class='go_button' value='Go'/></div><div style='clear:both;'></div></div>";
$total_string = "<div style='float:left;margin: 16px 0px;width: 30%;'><span class='total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b> of <b>$no_of_paginations</b></span></div>";
$msg = $msg . "<div style='clear:both;'></div></ul>" . $goto . $total_string . "<div style='clear:both;'></div></div>";  // Content for pagination
echo $msg;
?>