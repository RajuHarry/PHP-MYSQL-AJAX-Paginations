﻿1. Make database of any name
2. Import the sql file given in the zip file
3. change the name of database, db username and password in index.php

Now run and be happy.

Thanks.