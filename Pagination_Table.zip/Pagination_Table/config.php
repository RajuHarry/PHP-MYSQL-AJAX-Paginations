<?php 

$conn=mysql_connect("localhost","root","");
mysql_select_db("cmanage");
if (!$conn)
{
    die('Could not connect: ' . mysql_error());
}

/*
else 
{
	echo 'Connected';
}
*/

?>